#ifndef _SYS_CDEFS_H
#define _SYS_CDEFS_H    1

#ifndef _PID_T_DECLARED
typedef int     pid_t;  /* process id */
#define _PID_T_DECLARED
#endif

# include <features.h>
#endif   /* sys/cdefs.h */

